// @ts-ignore
global.window = {};
